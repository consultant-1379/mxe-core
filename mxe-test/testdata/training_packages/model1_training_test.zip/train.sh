#!/bin/bash

ls -lrth 

python3 create_model.py
